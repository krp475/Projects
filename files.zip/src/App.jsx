import React, { useState } from "react";
import "./App.css";

const users = [
  { name: "User297", online: true },
];

export default function App() {
  const [messages, setMessages] = useState([
    { system: true, text: "User297 has joined the chat" }
  ]);
  const [input, setInput] = useState("");

  function sendMessage() {
    if (input.trim()) {
      setMessages([...messages, { user: "User297", text: input }]);
      setInput("");
    }
  }

  return (
    <div className="win95-window">
      <div className="win95-titlebar">
        <div className="win95-title">CHAT - #GENERAL</div>
        <div className="win95-window-controls">
          <button className="win95-btn win95-btn-min" />
          <button className="win95-btn win95-btn-max" />
          <button className="win95-btn win95-btn-close" />
        </div>
      </div>
      <div className="win95-menubar">
        <span>File</span>
        <span>Edit</span>
        <span>View</span>
        <span>Help</span>
      </div>
      <div className="win95-main">
        <div className="win95-sidebar">
          <div className="win95-users-title">Users (1)</div>
          <div className="win95-users-list">
            <div className="win95-user">
              <span className="win95-user-dot" /> User297
            </div>
          </div>
        </div>
        <div className="win95-chat-area">
          <div className="win95-messages">
            {messages.map((msg, i) =>
              msg.system ? (
                <div className="win95-system-message" key={i}>{msg.text}</div>
              ) : (
                <div className="win95-chat-message" key={i}>
                  <b>{msg.user}</b>: {msg.text}
                </div>
              )
            )}
          </div>
          <div className="win95-chat-inputbar">
            <input
              className="win95-chat-input"
              placeholder="Type a message..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && sendMessage()}
            />
            <button className="win95-chat-send" onClick={sendMessage}>
              Send
            </button>
          </div>
          <div className="win95-statusbar">
            <span>Connected</span>
            <span className="win95-statusbar-right">1 online</span>
            <span className="win95-statusbar-time">09:31 PM</span>
          </div>
        </div>
      </div>
    </div>
  );
}